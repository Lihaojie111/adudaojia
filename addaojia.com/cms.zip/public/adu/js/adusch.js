/**
 * Created by Administrator on 2019/1/23.
 */
$(function () {
    $('.kl-item').click(function () {
        window.location.href='sch-detail.html'
    })
})