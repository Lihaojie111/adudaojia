<?php require 'tpl/header.php';?>
	<div class="main" style="background: rgba(255, 255, 255, 0.35);">
		<div class="complete">
				<p style="font-family: microsoft yahei,simhei; font-size:20px; font-weight:bold; color:#FF3300"><?php echo $lang['congratulations_installation_success'];?></p>
				<p><a href="../" target="_blank"  class="btn_blue"><?php echo $lang['visit_home'];?></a><a href="../index.php?s=admin" target="_blank" class="btn_blue"><?php echo $lang['enter_admin'];?></a></p>
				<p><?php echo $lang['safe_notes'];?></p>
		
		</div>
	</div>
</body>
</html>