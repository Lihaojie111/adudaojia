<?php require 'tpl/header.php';?>
	<div class="main" style="background: rgba(255, 255, 255, 0.35);">
		<div class="license">
		<?php echo format_textarea($license)?>			
		</div>
		<div class="action"><a href="index.php?step=2" class="btn_blue">接受协议</a></div>
	</div>
</body>
</html>