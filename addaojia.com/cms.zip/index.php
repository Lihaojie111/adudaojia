<?php
define('APP_PATH', __DIR__ . '/application/');

// 加载框架引导文件

require __DIR__ . '/thinkphp/start.php';