<?php return array (
  'type' => 'mysql',
  'hostname' => '127.0.0.1',
  'username' => 'root',
  'password' => 'root',
  'database' => 'cms',
  'prefix' => 'adu_',
  'dsn' => '',
  'charset' => 'utf8',
  'fields_strict' => false,
);?>