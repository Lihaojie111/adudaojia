<?php
/**
 * 行为配置
 *
 */
return [
    'action_begin' => [
        'app\\admin\\behavior\\operation'
    ],
];
