/**
 * Created by Administrator on 2019/1/22.
 */
$(function () {
	$('.top-right').click(function(){
		$('.tcode').toggle()
	})
})