<?php if (!defined('NONECMS_INSTALL')) exit('Access Denied!')?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>NoneCMS安装向导</title>
	<link rel="stylesheet" href="css/global.css" type="text/css" />
	<script type="text/javascript" src="../static/common/js/jquery1.42.min.js"></script>
</head>
<body>
<div class="header">
	<div class="logo">NoneCMS <span class="motto">-- 简简单单！</span></div>

	<div class="version">V1.2</div>
</div>