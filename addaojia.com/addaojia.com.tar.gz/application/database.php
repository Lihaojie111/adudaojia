<?php return array (
  'type' => 'mysql',
  'hostname' => '127.0.0.1',
  'username' => 'addaojia_com',
  'password' => 'WPYPSSiwN8FLfX7R',
  'database' => 'addaojia_com',
  'prefix' => 'adu_',
  'dsn' => '',
  'charset' => 'utf8',
  'fields_strict' => false,
);?>